
function hide(element) {
    element.remove();
}
function pet(element){
    element.innerText++
}