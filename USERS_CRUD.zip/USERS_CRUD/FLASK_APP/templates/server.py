from flask_app import app
# ...server.py

